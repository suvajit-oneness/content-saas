<?php



//blog category wise subcategory
Route::get('subcategory/{categoryId}', 'Api\ApiController@categorywiseSubcategory');
//subcategory wise tertiary category

