<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DealPage extends Model
{
    protected $table = 'deals_page'; 
}
