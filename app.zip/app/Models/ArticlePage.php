<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ArticlePage extends Model
{
    protected $table = 'article_page'; 
}
