<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlansPage extends Model
{
    protected $table = 'plans_and_pricing_page';
}
