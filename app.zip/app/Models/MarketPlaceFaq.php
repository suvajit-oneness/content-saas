<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarketPlaceFaq extends Model
{
    //
    protected $table = 'market_place_faqs';
}
