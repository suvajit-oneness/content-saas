<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarketPlacePage extends Model
{
    protected $table = 'marketplace_page'; 
}
