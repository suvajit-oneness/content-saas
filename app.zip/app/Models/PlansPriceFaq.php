<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlansPriceFaq extends Model
{
    //
    protected $table = 'plans_price_faqs';
}
