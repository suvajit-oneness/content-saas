<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EventPage extends Model
{
    protected $table = 'events_page'; 
}
