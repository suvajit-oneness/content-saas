<?php

namespace App\Contracts;

/**
 * Interface ProfileContract
 * @package App\Contracts
 */
interface ProfileContract
{
    

    /**
     * @param array $params
     * @return mixed
     */
    public function updateProfile(array $params);



}
