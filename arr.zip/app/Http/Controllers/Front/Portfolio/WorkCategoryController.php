<?php

namespace App\Http\Controllers\Front\Portfolio;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class WorkCategoryController extends Controller
{
    //
}
