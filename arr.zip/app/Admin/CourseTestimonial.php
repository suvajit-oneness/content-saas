<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class CourseTestimonial extends Model
{
    //
}
